"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'sessionLogout';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'sessionLogout';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsZUFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLGVBQXBCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IFBMVUdJTl9JRCA9ICdzZXNzaW9uTG9nb3V0JztcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdzZXNzaW9uTG9nb3V0JztcbiJdfQ==